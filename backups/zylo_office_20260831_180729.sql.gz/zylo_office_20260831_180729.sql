--
-- PostgreSQL database dump
--

\restrict rfNYjrbhqT4G48DLy3wFVPb6hLpDwVbpBAssFNTXBBhAIF5MDTh8omNe7OToEpy

-- Dumped from database version 17.11 (Debian 17.11-0+deb13u1)
-- Dumped by pg_dump version 17.11 (Debian 17.11-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO zylo_office;

--
-- Name: invoice; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public.invoice (
    "subscriptionId" uuid NOT NULL,
    "amountCents" numeric(12,0) NOT NULL,
    currency character varying(3) NOT NULL,
    status character varying(50) NOT NULL,
    "issuedAt" timestamp with time zone NOT NULL,
    "paidAt" timestamp with time zone,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invoice OWNER TO zylo_office;

--
-- Name: TABLE invoice; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public.invoice IS 'Facture émise pour un abonnement — le règlement réel (prestataire de paiement) n''est pas implémenté dans ce socle.';


--
-- Name: module; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public.module (
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(500),
    version character varying(50) NOT NULL,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.module OWNER TO zylo_office;

--
-- Name: TABLE module; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public.module IS 'Registre statique des modules connus du système (CRM, Stock, zylo_liquid...).';


--
-- Name: organization; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public.organization (
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public.organization OWNER TO zylo_office;

--
-- Name: TABLE organization; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public.organization IS 'Organisation cliente de Zylo Office — tenant racine du système multi-organisation.';


--
-- Name: organizationModule; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public."organizationModule" (
    "organizationId" uuid NOT NULL,
    "moduleCode" character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    "activatedAt" timestamp with time zone,
    "deactivatedAt" timestamp with time zone,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."organizationModule" OWNER TO zylo_office;

--
-- Name: TABLE "organizationModule"; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public."organizationModule" IS 'État d''activation d''un module pour une organisation donnée (active/inactive/trial).';


--
-- Name: organizationUser; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public."organizationUser" (
    "organizationId" uuid NOT NULL,
    "userId" uuid NOT NULL,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."organizationUser" OWNER TO zylo_office;

--
-- Name: TABLE "organizationUser"; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public."organizationUser" IS 'Association utilisateur <-> organisation (appartenance, many-to-many).';


--
-- Name: permission; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public.permission (
    code character varying(150) NOT NULL,
    "moduleCode" character varying(100) NOT NULL,
    description character varying(255),
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.permission OWNER TO zylo_office;

--
-- Name: TABLE permission; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public.permission IS 'Permission globale au système, déclarée par un module (convention: module.resource.action).';


--
-- Name: plan; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public.plan (
    "moduleCode" character varying(100) NOT NULL,
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    "priceCents" numeric(12,0) NOT NULL,
    currency character varying(3) NOT NULL,
    "periodDays" integer NOT NULL,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plan OWNER TO zylo_office;

--
-- Name: TABLE plan; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public.plan IS 'Offre commerciale pour un module donné (prix, période, fonctionnalités incluses).';


--
-- Name: refreshToken; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public."refreshToken" (
    "userId" uuid NOT NULL,
    "tokenHash" character varying(255) NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "revokedAt" timestamp with time zone,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."refreshToken" OWNER TO zylo_office;

--
-- Name: TABLE "refreshToken"; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public."refreshToken" IS 'Refresh token JWT émis à un utilisateur — révocable individuellement, avec rotation à chaque renouvellement.';


--
-- Name: role; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public.role (
    "organizationId" uuid NOT NULL,
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.role OWNER TO zylo_office;

--
-- Name: TABLE role; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public.role IS 'Rôle métier scopé à une organisation (ex: Admin, Comptable).';


--
-- Name: rolePermission; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public."rolePermission" (
    "roleId" uuid NOT NULL,
    "permissionId" uuid NOT NULL,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."rolePermission" OWNER TO zylo_office;

--
-- Name: TABLE "rolePermission"; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public."rolePermission" IS 'Association rôle <-> permission (many-to-many).';


--
-- Name: subscription; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public.subscription (
    "organizationId" uuid NOT NULL,
    "planId" uuid NOT NULL,
    status character varying(50) NOT NULL,
    "startDate" timestamp with time zone NOT NULL,
    "endDate" timestamp with time zone NOT NULL,
    "renewedAt" timestamp with time zone,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription OWNER TO zylo_office;

--
-- Name: TABLE subscription; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public.subscription IS 'Abonnement d''une organisation à un plan — statut trial/active/expired/cancelled.';


--
-- Name: user; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public."user" (
    email character varying(320) NOT NULL,
    "hashedPassword" character varying(255) NOT NULL,
    "fullName" character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."user" OWNER TO zylo_office;

--
-- Name: TABLE "user"; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public."user" IS 'Utilisateur du système — identité unique, valable pour toutes les organisations et tous les modules.';


--
-- Name: userRole; Type: TABLE; Schema: public; Owner: zylo_office
--

CREATE TABLE public."userRole" (
    "userId" uuid NOT NULL,
    "organizationId" uuid NOT NULL,
    "roleId" uuid NOT NULL,
    id uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."userRole" OWNER TO zylo_office;

--
-- Name: TABLE "userRole"; Type: COMMENT; Schema: public; Owner: zylo_office
--

COMMENT ON TABLE public."userRole" IS 'Attribution d''un rôle à un utilisateur, scopée à une organisation (un même user peut avoir un rôle différent selon l''organisation).';


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public.alembic_version (version_num) FROM stdin;
da0ccc1f6d2c
\.


--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public.invoice ("subscriptionId", "amountCents", currency, status, "issuedAt", "paidAt", id, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: module; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public.module (code, name, description, version, id, "createdAt", "updatedAt") FROM stdin;
zylo_liquid	Zylo Liquid	Gestion de station-service (cuves, sondes, HK301).	0.1.0	7392331b-3e10-49b3-99d1-10c830964869	2026-08-31 17:31:09.814337-04	2026-08-31 17:31:09.814337-04
\.


--
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public.organization (name, slug, status, id, "createdAt", "updatedAt", "deletedAt") FROM stdin;
Org Test 56	org-test-56-24362	active	94143856-a3ea-41ae-a44c-cd5c56aaff25	2026-08-31 17:22:46.498381-04	2026-08-31 17:22:46.498381-04	\N
Org Test 56	org-test-56-27644	active	ee98e6c8-9732-4427-a459-73f55833f33e	2026-08-31 17:24:03.918304-04	2026-08-31 17:24:03.918304-04	\N
Org Test 7	org-test-7-4897	active	07d1332c-2044-46a9-88d8-3f336c8a9de3	2026-08-31 17:32:03.320395-04	2026-08-31 17:32:03.320395-04	\N
Org Test 7	org-test-7-5702	active	011b17de-783b-48aa-baaa-45c0b9071468	2026-08-31 17:33:57.532774-04	2026-08-31 17:33:57.532774-04	\N
Org Test 10	org-test-10-32222	active	45060d47-02f9-4c5d-99ac-8915e316689e	2026-08-31 18:05:11.609974-04	2026-08-31 18:05:11.609974-04	\N
\.


--
-- Data for Name: organizationModule; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public."organizationModule" ("organizationId", "moduleCode", status, "activatedAt", "deactivatedAt", id, "createdAt", "updatedAt") FROM stdin;
011b17de-783b-48aa-baaa-45c0b9071468	zylo_liquid	inactive	2026-08-31 17:33:57.840914-04	2026-08-31 17:33:57.964461-04	7ac5f05f-4521-4d72-95e3-ebc8574c42c0	2026-08-31 17:33:57.82282-04	2026-08-31 17:33:57.953318-04
\.


--
-- Data for Name: organizationUser; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public."organizationUser" ("organizationId", "userId", id, "createdAt", "updatedAt") FROM stdin;
94143856-a3ea-41ae-a44c-cd5c56aaff25	a0d949d9-8519-4cc0-b604-ed353cc219f0	afae7fd4-8db9-4a69-b3cf-de52a6789936	2026-08-31 17:22:46.498381-04	2026-08-31 17:22:46.498381-04
ee98e6c8-9732-4427-a459-73f55833f33e	eeac8392-cb14-46f8-8c87-96ae14f159ed	bc6bbcdb-3114-4d1b-8ec7-2876b59274ce	2026-08-31 17:24:03.918304-04	2026-08-31 17:24:03.918304-04
07d1332c-2044-46a9-88d8-3f336c8a9de3	e05f7f03-20ac-4c17-ac25-c21317790440	90c0b3cf-5bc3-49c1-ac55-eb6836d760d1	2026-08-31 17:32:03.320395-04	2026-08-31 17:32:03.320395-04
011b17de-783b-48aa-baaa-45c0b9071468	4d5b7a50-424e-4d0a-acbe-b7088e48cc14	bb1cd0e7-e68d-4bc2-bc0d-e68c56f2704c	2026-08-31 17:33:57.532774-04	2026-08-31 17:33:57.532774-04
45060d47-02f9-4c5d-99ac-8915e316689e	d3b7a34f-e73d-47c1-94b0-1b49716ae534	16b06c42-b5fe-4689-a3af-4dd8b4d8ca8e	2026-08-31 18:05:11.609974-04	2026-08-31 18:05:11.609974-04
\.


--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public.permission (code, "moduleCode", description, id, "createdAt", "updatedAt") FROM stdin;
identity.organization.manage	identity	Gérer l'organisation (membres, rôles, paramètres).	ba2c3cb2-f064-4976-9cb4-a6dc2636e896	2026-08-31 17:22:46.498381-04	2026-08-31 17:22:46.498381-04
modules.module.manage	modules_registry	Activer/désactiver les modules pour l'organisation.	84317f59-f61f-4d78-8ac6-6e5a035f88dd	2026-08-31 17:33:57.532774-04	2026-08-31 17:33:57.532774-04
billing.subscription.manage	billing	Gérer les abonnements de l'organisation.	6b57b5ac-a3b8-47b4-8c92-6275c1b0fe11	2026-08-31 18:05:11.609974-04	2026-08-31 18:05:11.609974-04
\.


--
-- Data for Name: plan; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public.plan ("moduleCode", code, name, "priceCents", currency, "periodDays", id, "createdAt", "updatedAt") FROM stdin;
zylo_liquid	zylo_liquid_basic_12822	Zylo Liquid Basic	500000	XAF	30	a8a0ef69-a0e3-43fb-800b-9803854ed385	2026-08-31 18:05:11.861276-04	2026-08-31 18:05:11.861276-04
\.


--
-- Data for Name: refreshToken; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public."refreshToken" ("userId", "tokenHash", "expiresAt", "revokedAt", id, "createdAt", "updatedAt") FROM stdin;
a0d949d9-8519-4cc0-b604-ed353cc219f0	f83d989bbcb755c4c3e2a04629816ed7f3ec92ece8f08b4ce07aa564af60a971	2026-09-30 17:22:46.218197-04	\N	52d97836-f3ea-486f-874a-37a30233b494	2026-08-31 17:22:45.052806-04	2026-08-31 17:22:45.052806-04
eeac8392-cb14-46f8-8c87-96ae14f159ed	df6f7bb236280d1b1dff16d0d03a901df54ade9df89bbd1b56e53cd6e2b31b49	2026-09-30 17:24:03.620729-04	2026-08-31 17:24:04.217642-04	9b0a065e-233b-44b7-a9d7-8fc7672e754c	2026-08-31 17:24:02.459888-04	2026-08-31 17:24:04.214282-04
eeac8392-cb14-46f8-8c87-96ae14f159ed	48d8c0ec04bfcc77e3f602d35cc90c30c35f2fa9af95f3807bc4df0106aaf0e4	2026-09-30 17:24:04.229104-04	2026-08-31 17:24:04.402932-04	47abcfac-28c4-4f29-9239-c6c044e31520	2026-08-31 17:24:04.214282-04	2026-08-31 17:24:04.400931-04
e05f7f03-20ac-4c17-ac25-c21317790440	00341e598e1886a0899054366ee7747d12705125e6af06bc5c388a075bb9bd9c	2026-09-30 17:32:03.180212-04	\N	6c38187c-f6a1-4dc4-9044-3a0859c15cbf	2026-08-31 17:32:02.020728-04	2026-08-31 17:32:02.020728-04
4d5b7a50-424e-4d0a-acbe-b7088e48cc14	2696d7ef5ad4707ea855ad55f8d95266e6d385f0cf3262594dd65f5fa2f6e778	2026-09-30 17:33:57.380158-04	\N	b90d9800-a681-4f39-9a97-334a63274afb	2026-08-31 17:33:56.225951-04	2026-08-31 17:33:56.225951-04
abb1a6c5-db6c-4d6d-89aa-5a77bf43bb11	5eebebd73dee0a2b8e8a10c3563671935e57f0b869020935d7d286d67a35230f	2026-09-30 17:52:43.984697-04	2026-08-31 17:52:44.518458-04	008b2c6d-e76d-4d7f-b170-95fa62d1a3b0	2026-08-31 17:52:42.786342-04	2026-08-31 17:52:44.514543-04
abb1a6c5-db6c-4d6d-89aa-5a77bf43bb11	37ca6763f1611e0779c36b448a8271f481f534d01d4f5fabf7194b9e40b07fd2	2026-09-30 17:55:28.225007-04	2026-08-31 17:55:31.22587-04	54ec1d10-deff-4585-bc9a-4c032858d26c	2026-08-31 17:55:27.068704-04	2026-08-31 17:55:31.223887-04
d3b7a34f-e73d-47c1-94b0-1b49716ae534	aaa5ddae9a3b4c2561549064e8b46a1d4c3f0b70c82a3a67f0fd6463aba56d47	2026-09-30 18:05:11.454249-04	\N	a2f18163-def8-4cd2-ad9d-b59e268889ed	2026-08-31 18:05:10.294837-04	2026-08-31 18:05:10.294837-04
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public.role ("organizationId", code, name, id, "createdAt", "updatedAt") FROM stdin;
94143856-a3ea-41ae-a44c-cd5c56aaff25	owner	Propriétaire	045d9ecf-a1ea-4066-b375-4fe65cefa104	2026-08-31 17:22:46.498381-04	2026-08-31 17:22:46.498381-04
ee98e6c8-9732-4427-a459-73f55833f33e	owner	Propriétaire	220d7c49-9bbc-44e9-96a5-c3010770009d	2026-08-31 17:24:03.918304-04	2026-08-31 17:24:03.918304-04
07d1332c-2044-46a9-88d8-3f336c8a9de3	owner	Propriétaire	eb413752-ccfe-4c6c-964e-f5be950645b6	2026-08-31 17:32:03.320395-04	2026-08-31 17:32:03.320395-04
011b17de-783b-48aa-baaa-45c0b9071468	owner	Propriétaire	b41edcfe-a9fb-404f-a0a6-2db19a9b5b76	2026-08-31 17:33:57.532774-04	2026-08-31 17:33:57.532774-04
45060d47-02f9-4c5d-99ac-8915e316689e	owner	Propriétaire	f55dcd81-1e9e-4ee0-ba8e-f8b03474ed3d	2026-08-31 18:05:11.609974-04	2026-08-31 18:05:11.609974-04
\.


--
-- Data for Name: rolePermission; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public."rolePermission" ("roleId", "permissionId", id, "createdAt", "updatedAt") FROM stdin;
045d9ecf-a1ea-4066-b375-4fe65cefa104	ba2c3cb2-f064-4976-9cb4-a6dc2636e896	948dfc1a-e815-457e-8245-5dc62d5e2221	2026-08-31 17:22:46.498381-04	2026-08-31 17:22:46.498381-04
220d7c49-9bbc-44e9-96a5-c3010770009d	ba2c3cb2-f064-4976-9cb4-a6dc2636e896	f8dccc4f-8627-46db-bd86-602a17037a74	2026-08-31 17:24:03.918304-04	2026-08-31 17:24:03.918304-04
eb413752-ccfe-4c6c-964e-f5be950645b6	ba2c3cb2-f064-4976-9cb4-a6dc2636e896	e63525bc-ea3b-4aa5-8a11-03d8cb643849	2026-08-31 17:32:03.320395-04	2026-08-31 17:32:03.320395-04
b41edcfe-a9fb-404f-a0a6-2db19a9b5b76	ba2c3cb2-f064-4976-9cb4-a6dc2636e896	f06155b4-5ace-465d-9eb2-f665847cfc6c	2026-08-31 17:33:57.532774-04	2026-08-31 17:33:57.532774-04
b41edcfe-a9fb-404f-a0a6-2db19a9b5b76	84317f59-f61f-4d78-8ac6-6e5a035f88dd	84271651-28fb-4590-9303-53b514e7d7ba	2026-08-31 17:33:57.532774-04	2026-08-31 17:33:57.532774-04
f55dcd81-1e9e-4ee0-ba8e-f8b03474ed3d	ba2c3cb2-f064-4976-9cb4-a6dc2636e896	e899c1c6-6218-4537-abc3-60120bb4fb0c	2026-08-31 18:05:11.609974-04	2026-08-31 18:05:11.609974-04
f55dcd81-1e9e-4ee0-ba8e-f8b03474ed3d	84317f59-f61f-4d78-8ac6-6e5a035f88dd	bec2f17e-9cab-4b40-b552-77967acd829b	2026-08-31 18:05:11.609974-04	2026-08-31 18:05:11.609974-04
f55dcd81-1e9e-4ee0-ba8e-f8b03474ed3d	6b57b5ac-a3b8-47b4-8c92-6275c1b0fe11	a20f55dd-70c8-4207-9e61-f0ea5d45db19	2026-08-31 18:05:11.609974-04	2026-08-31 18:05:11.609974-04
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public.subscription ("organizationId", "planId", status, "startDate", "endDate", "renewedAt", id, "createdAt", "updatedAt") FROM stdin;
45060d47-02f9-4c5d-99ac-8915e316689e	a8a0ef69-a0e3-43fb-800b-9803854ed385	trial	2026-08-31 18:05:12.009446-04	2026-09-30 18:05:12.009446-04	\N	63d797b2-d4f7-41a7-b242-383b1b1aac86	2026-08-31 18:05:11.977723-04	2026-08-31 18:05:11.977723-04
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public."user" (email, "hashedPassword", "fullName", status, id, "createdAt", "updatedAt", "deletedAt") FROM stdin;
test-phase56-20600@zylo-office-test.example.com	$2b$12$YPwHb0XganHVYe63u22imOMXlufSsaubVvgInL9s26vH5c3pOCWsm	Test Phase56	active	a0d949d9-8519-4cc0-b604-ed353cc219f0	2026-08-31 17:22:43.723131-04	2026-08-31 17:22:43.723131-04	\N
test-phase56-1772@zylo-office-test.example.com	$2b$12$l.e.0AMtgARQVh1bMGHdteCk8jzQxM7srNJYe1zh5q6z5JuSDxY3S	Test Phase56	active	eeac8392-cb14-46f8-8c87-96ae14f159ed	2026-08-31 17:24:01.134889-04	2026-08-31 17:24:01.134889-04	\N
test-phase7-6168@zylo-office-test.example.com	$2b$12$kl1PX36SHun.OLjnPjtSseLh1.AqaO.uKlxdWb97qv1S3ViKq4BkK	Test Phase7	active	e05f7f03-20ac-4c17-ac25-c21317790440	2026-08-31 17:32:00.706053-04	2026-08-31 17:32:00.706053-04	\N
test-phase7-2296@zylo-office-test.example.com	$2b$12$Ppk9RdDDtZ42yVJnL0S1bOqAYb4VaMEY3KkcC4M8MWaEUB5JurjG6	Test Phase7	active	4d5b7a50-424e-4d0a-acbe-b7088e48cc14	2026-08-31 17:33:54.905524-04	2026-08-31 17:33:54.905524-04	\N
frontend-test-25280@zylo-office-test.example.com	$2b$12$2xc.eMnDnSzeXPvT0FIxFeT3TLNoe7peYl2lXKK4OCEEhhaLZU.uS	Frontend Test	active	abb1a6c5-db6c-4d6d-89aa-5a77bf43bb11	2026-08-31 17:48:41.669726-04	2026-08-31 17:48:41.669726-04	\N
test-phase10-7320@zylo-office-test.example.com	$2b$12$IVGwly7SNyV7x3yNLiWuKuG8Jj7EEl9yYWHIOEHBbh5hSvpihIqvC	Test Phase10	active	d3b7a34f-e73d-47c1-94b0-1b49716ae534	2026-08-31 18:05:08.977103-04	2026-08-31 18:05:08.977103-04	\N
\.


--
-- Data for Name: userRole; Type: TABLE DATA; Schema: public; Owner: zylo_office
--

COPY public."userRole" ("userId", "organizationId", "roleId", id, "createdAt", "updatedAt") FROM stdin;
a0d949d9-8519-4cc0-b604-ed353cc219f0	94143856-a3ea-41ae-a44c-cd5c56aaff25	045d9ecf-a1ea-4066-b375-4fe65cefa104	43076b1c-0ae9-41c1-8e70-bb7a218d67c5	2026-08-31 17:22:46.498381-04	2026-08-31 17:22:46.498381-04
eeac8392-cb14-46f8-8c87-96ae14f159ed	ee98e6c8-9732-4427-a459-73f55833f33e	220d7c49-9bbc-44e9-96a5-c3010770009d	1f5bcc85-5253-4764-9bec-f888201dc96b	2026-08-31 17:24:03.918304-04	2026-08-31 17:24:03.918304-04
e05f7f03-20ac-4c17-ac25-c21317790440	07d1332c-2044-46a9-88d8-3f336c8a9de3	eb413752-ccfe-4c6c-964e-f5be950645b6	a4fe8a30-135d-4182-a600-4c459d8a7bc3	2026-08-31 17:32:03.320395-04	2026-08-31 17:32:03.320395-04
4d5b7a50-424e-4d0a-acbe-b7088e48cc14	011b17de-783b-48aa-baaa-45c0b9071468	b41edcfe-a9fb-404f-a0a6-2db19a9b5b76	c895af30-a17d-4792-8472-2a42ab3b8808	2026-08-31 17:33:57.532774-04	2026-08-31 17:33:57.532774-04
d3b7a34f-e73d-47c1-94b0-1b49716ae534	45060d47-02f9-4c5d-99ac-8915e316689e	f55dcd81-1e9e-4ee0-ba8e-f8b03474ed3d	ee0eb5cd-7568-47ac-8c70-3af6b6fc50ac	2026-08-31 18:05:11.609974-04	2026-08-31 18:05:11.609974-04
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: invoice invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (id);


--
-- Name: module module_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.module
    ADD CONSTRAINT module_pkey PRIMARY KEY (id);


--
-- Name: organizationModule organizationModule_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."organizationModule"
    ADD CONSTRAINT "organizationModule_pkey" PRIMARY KEY (id);


--
-- Name: organizationUser organizationUser_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."organizationUser"
    ADD CONSTRAINT "organizationUser_pkey" PRIMARY KEY (id);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: organization organization_slug_key; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_slug_key UNIQUE (slug);


--
-- Name: permission permission_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT permission_pkey PRIMARY KEY (id);


--
-- Name: plan plan_code_key; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.plan
    ADD CONSTRAINT plan_code_key UNIQUE (code);


--
-- Name: plan plan_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.plan
    ADD CONSTRAINT plan_pkey PRIMARY KEY (id);


--
-- Name: refreshToken refreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."refreshToken"
    ADD CONSTRAINT "refreshToken_pkey" PRIMARY KEY (id);


--
-- Name: refreshToken refreshToken_tokenHash_key; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."refreshToken"
    ADD CONSTRAINT "refreshToken_tokenHash_key" UNIQUE ("tokenHash");


--
-- Name: rolePermission rolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."rolePermission"
    ADD CONSTRAINT "rolePermission_pkey" PRIMARY KEY (id);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (id);


--
-- Name: organizationModule uq_organizationModule_org_module; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."organizationModule"
    ADD CONSTRAINT "uq_organizationModule_org_module" UNIQUE ("organizationId", "moduleCode");


--
-- Name: organizationUser uq_organizationUser_org_user; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."organizationUser"
    ADD CONSTRAINT "uq_organizationUser_org_user" UNIQUE ("organizationId", "userId");


--
-- Name: rolePermission uq_rolePermission_role_perm; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."rolePermission"
    ADD CONSTRAINT "uq_rolePermission_role_perm" UNIQUE ("roleId", "permissionId");


--
-- Name: role uq_role_org_code; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT uq_role_org_code UNIQUE ("organizationId", code);


--
-- Name: userRole uq_userRole_user_org_role; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."userRole"
    ADD CONSTRAINT "uq_userRole_user_org_role" UNIQUE ("userId", "organizationId", "roleId");


--
-- Name: userRole userRole_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."userRole"
    ADD CONSTRAINT "userRole_pkey" PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: ix_invoice_subscriptionId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_invoice_subscriptionId" ON public.invoice USING btree ("subscriptionId");


--
-- Name: ix_module_code; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE UNIQUE INDEX ix_module_code ON public.module USING btree (code);


--
-- Name: ix_organizationModule_moduleCode; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_organizationModule_moduleCode" ON public."organizationModule" USING btree ("moduleCode");


--
-- Name: ix_organizationModule_organizationId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_organizationModule_organizationId" ON public."organizationModule" USING btree ("organizationId");


--
-- Name: ix_organizationUser_organizationId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_organizationUser_organizationId" ON public."organizationUser" USING btree ("organizationId");


--
-- Name: ix_organizationUser_userId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_organizationUser_userId" ON public."organizationUser" USING btree ("userId");


--
-- Name: ix_permission_code; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE UNIQUE INDEX ix_permission_code ON public.permission USING btree (code);


--
-- Name: ix_permission_moduleCode; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_permission_moduleCode" ON public.permission USING btree ("moduleCode");


--
-- Name: ix_plan_moduleCode; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_plan_moduleCode" ON public.plan USING btree ("moduleCode");


--
-- Name: ix_refreshToken_userId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_refreshToken_userId" ON public."refreshToken" USING btree ("userId");


--
-- Name: ix_rolePermission_permissionId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_rolePermission_permissionId" ON public."rolePermission" USING btree ("permissionId");


--
-- Name: ix_rolePermission_roleId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_rolePermission_roleId" ON public."rolePermission" USING btree ("roleId");


--
-- Name: ix_role_organizationId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_role_organizationId" ON public.role USING btree ("organizationId");


--
-- Name: ix_subscription_organizationId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_subscription_organizationId" ON public.subscription USING btree ("organizationId");


--
-- Name: ix_subscription_planId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_subscription_planId" ON public.subscription USING btree ("planId");


--
-- Name: ix_userRole_organizationId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_userRole_organizationId" ON public."userRole" USING btree ("organizationId");


--
-- Name: ix_userRole_roleId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_userRole_roleId" ON public."userRole" USING btree ("roleId");


--
-- Name: ix_userRole_userId; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE INDEX "ix_userRole_userId" ON public."userRole" USING btree ("userId");


--
-- Name: ix_user_email; Type: INDEX; Schema: public; Owner: zylo_office
--

CREATE UNIQUE INDEX ix_user_email ON public."user" USING btree (email);


--
-- Name: invoice invoice_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT "invoice_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscription(id);


--
-- Name: organizationModule organizationModule_moduleCode_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."organizationModule"
    ADD CONSTRAINT "organizationModule_moduleCode_fkey" FOREIGN KEY ("moduleCode") REFERENCES public.module(code);


--
-- Name: organizationModule organizationModule_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."organizationModule"
    ADD CONSTRAINT "organizationModule_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public.organization(id);


--
-- Name: organizationUser organizationUser_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."organizationUser"
    ADD CONSTRAINT "organizationUser_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public.organization(id);


--
-- Name: organizationUser organizationUser_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."organizationUser"
    ADD CONSTRAINT "organizationUser_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: plan plan_moduleCode_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.plan
    ADD CONSTRAINT "plan_moduleCode_fkey" FOREIGN KEY ("moduleCode") REFERENCES public.module(code);


--
-- Name: refreshToken refreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."refreshToken"
    ADD CONSTRAINT "refreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: rolePermission rolePermission_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."rolePermission"
    ADD CONSTRAINT "rolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.permission(id);


--
-- Name: rolePermission rolePermission_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."rolePermission"
    ADD CONSTRAINT "rolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.role(id);


--
-- Name: role role_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT "role_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public.organization(id);


--
-- Name: subscription subscription_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT "subscription_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public.organization(id);


--
-- Name: subscription subscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT "subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.plan(id);


--
-- Name: userRole userRole_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."userRole"
    ADD CONSTRAINT "userRole_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public.organization(id);


--
-- Name: userRole userRole_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."userRole"
    ADD CONSTRAINT "userRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.role(id);


--
-- Name: userRole userRole_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zylo_office
--

ALTER TABLE ONLY public."userRole"
    ADD CONSTRAINT "userRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO zylo_office;


--
-- PostgreSQL database dump complete
--

\unrestrict rfNYjrbhqT4G48DLy3wFVPb6hLpDwVbpBAssFNTXBBhAIF5MDTh8omNe7OToEpy

